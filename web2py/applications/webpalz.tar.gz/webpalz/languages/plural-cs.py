#!/usr/bin/env python
{
# "singular form (0)": ["first plural form (1)", "second plural form (2)", ...],
'vteřina': ['vteřiny', 'vteřin'],
'vteřinou': ['vteřinami', 'vteřinami'],
'minuta': ['minuty', 'minut'],
'minutou': ['minutami', 'minutami'],
'hodina': ['hodiny','hodin'],
'hodinou': ['hodinami','hodinami'],
'den': ['dny','dnů'],
'dnem': ['dny','dny'],
'týden': ['týdny','týdnů'],
'týdnem': ['týdny','týdny'],
'měsíc': ['měsíce','měsíců'],
'měsícem': ['měsíci','měsíci'],
'rok': ['roky','let'],
'rokem': ['roky','lety'],
'záznam': ['záznamy', 'záznamů'],
'soubor': ['soubory', 'souborů']
}
